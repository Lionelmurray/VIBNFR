class UserRegistration {
  String name = '';
  int age = 0;
  String email = '';
  String password = '';
  String localProfilePhotoPath = '';
}
